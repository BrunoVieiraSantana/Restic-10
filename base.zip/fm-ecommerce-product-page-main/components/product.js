import styles from "./product.module.css";
import ProductGallery from "./productGallery";
import utils from "./utils.module.css";

export default function Product() {
  return <></>;
}
