document.addEventListener("DOMContentLoaded", function () {
    const visor = document.getElementById("display");
    let entradaAtual = "";
    let expressaoAtual = [];
  
    document.querySelectorAll("button").forEach(function (botao) {
      botao.addEventListener("click", function () {
        manipularClique(botao.textContent);
      });
    });
  
    function manipularClique(valor) {
      switch (valor) {
        case "AC":
          limparTudo();
          break;
        case "DEL":
          apagarUltimo();
          break;
        case "=":
          avaliarExpressao();
          break;
        default:
          atualizarVisor(valor);
          break;
      }
    }
  
    function limparTudo() {
      entradaAtual = "";
      expressaoAtual = [];
      atualizarVisor();
    }
  
    function apagarUltimo() {
      entradaAtual = entradaAtual.slice(0, -1);
      atualizarVisor();
    }
  
    function atualizarVisor(valor) {
      if (valor) {
        entradaAtual += valor;
      }
      visor.value = entradaAtual;
    }
  
    function avaliarExpressao() {
      try {
        const resultado = calcularExpressao();
        entradaAtual = resultado;
        expressaoAtual = [resultado];
        atualizarVisor();
      } catch (erro) {
        entradaAtual = "Erro";
        atualizarVisor();
      }
    }
  
    function calcularExpressao() {
      const regexMulDiv = /(\d+(\.\d+)?)[*/](\d+(\.\d+)?)/;
      
      while (regexMulDiv.test(entradaAtual)) {
        entradaAtual = entradaAtual.replace(regexMulDiv, (match, num1, _, num2) => {
          const resultado = match.includes("*") ? parseFloat(num1) * parseFloat(num2) : parseFloat(num1) / parseFloat(num2);
          return resultado.toString();
        });
      }
  

      const regexAddSub = /(\d+(\.\d+)?)[+\-](\d+(\.\d+)?)/;
      
      while (regexAddSub.test(entradaAtual)) {
        entradaAtual = entradaAtual.replace(regexAddSub, (match, num1, _, num2) => {
          const resultado = match.includes("+") ? parseFloat(num1) + parseFloat(num2) : parseFloat(num1) - parseFloat(num2);
          return resultado.toString();
        });
      }
  
      return entradaAtual;
    }
  });
  