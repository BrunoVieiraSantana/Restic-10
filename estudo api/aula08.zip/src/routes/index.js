const personsRouter = require('./persons')

module.exports = {
    personsRouter
}