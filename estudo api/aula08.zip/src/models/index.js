const personsModel = require('./persons')
const phonesModel = require('./phones')

module.exports = {
    personsModel,
    phonesModel
}